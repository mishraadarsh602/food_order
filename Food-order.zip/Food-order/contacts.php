<style>
    .row-box {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 40px auto;
        flex-direction: row;
    }

    .row-box2 {
        margin: 40px auto;
    }

    .mb-3 {
        margin-bottom: 10px;
    }

    .mb-3 input,
    .mb-3 textarea {
        padding: 5px;
        width: 300px;

    }

    h4 {
        color: #ff003f;
        margin-bottom: 10px;
    }

    .submit {
        background-color: #ff003f;
        color: white;
        padding: 6px 10px;
        border: none;
        outline: none;
        cursor: pointer;
    }
    .text-success{
        color:green;
    }
    .text-danger{
        color:red;
    }

    @media (max-width:820px) {
        .row-box {
            flex-direction: column;
        }

        .row-box div {
            margin: 20px auto;
        }
    }
</style>
<!--including menu bar-->
<?php include('partials-front/menu.php') ?>
<!-- Bootstrap CSS -->



<!-------main-content section starts-->
<div class="main-content">
    <div class="wrapper">
        <h2 style="margin:10px;text-align:center;">Contact us</h2>
        <div id="mainBody">
            <div class="container">
                <hr class="soften">
                <br>
                <?php 
                if(isset($_SESSION['contact'])){
                    echo $_SESSION['contact'];
                    unset($_SESSION['contact']);
                }
                ?>

                <div class="row row-box">
                    <div class="col-md-4 col-lg-4 col-sm-12 col-12">
                        <h4>Contact Details</h4>
                        <address style="color:black">
                            <span>AYANAGAR<br></span>Bandh RoAD<br>
                            New Delhi-110047<br>
                            <span>Phone: <a style="color:black" href="tel:9958283112">(995) 828-3112</a></span>
                        </address>
                    </div>

                    <div class="col-md-4 col-lg-4 col-sm-12 col-124">
                        <h4>Opening Hours</h4>
                        <h5> Monday - Sunday</h5>
                        <p>24/7 Available<br><br></p>

                    </div>
                    <div class="col-md-4 col-lg-4 col-sm-12 col-12">
                        <form action="" method="POST">
                            <h4>Email Us</h4>
                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label><br>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Email address</label><br>
                                <input type="email" name="email_address" class="form-control"
                                    id="exampleFormControlInput1" placeholder="Email">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Message</label><br>
                                <textarea class="form-control" name="message" placeholder="Your Message......."
                                    id="exampleFormControlTextarea1" rows="3"></textarea>
                            </div>
                            <input type="submit" name="submit" class="submit" value="Submit">
                        </form>  
                        
                        <?php
                        
                        if(isset($_POST['submit'])){

                            $name = $_POST['name'];
                            $email_address = $_POST['email_address'];
                            $message = $_POST['message'];

                            $sql = "INSERT INTO contact  SET
                            name= '$name',
                            email_address = '$email_address',
                            message = '$message'  
                            ";

                            //execute the query
                            $res = mysqli_query($conn , $sql);
                            if($res==true){
                                $_SESSION['contact']="<div class='text-center text-success'>Your Contact is  inserted successfully!!</div>";
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                            else{
                                $_SESSION['contact']="<div class='text-center text-danger'>Your Contact is not  inserted !! Try again</div>";
                                header('location:'.SITEURL.'contacts.php');

                            }

                        }
                        
                        ?>
                    </div>
                </div>
                <div class="row row-box2">
                    <div class="span12">
                        <div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no"
                                marginheight="0" marginwidth="0"
                                src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=aya%20nagar,%20new%20delhi+(A2%20STORE)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a
                                href="https://www.maps.ie/draw-radius-circle-map/">Measure km radius</a></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
    crossorigin="anonymous"></script>

<!--including footer-->
<?php include('partials-front/footer.php') ?>