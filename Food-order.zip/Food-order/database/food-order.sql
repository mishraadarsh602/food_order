-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2021 at 08:15 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food-order`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(19, 'rahul ', 'rahul', '439ed537979d8e831561964dbbbd7413'),
(20, 'am', 'am', 'c04cd38aeb30f3ad1f8ab4e64a0ded7b'),
(22, 'akm', 'akm', 'c6a7d2c304e4c34d720c900db714fa40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(22, 'Pizza', 'Food_Category_417.jpg', 'Yes', 'Yes'),
(24, 'Burger', 'Food_Category_749.jpg', 'Yes', 'Yes'),
(25, 'Momo', 'Food_Category_80.jpg', 'Yes', 'Yes'),
(26, 'Pasta', 'Food_Category_550.jpg', 'Yes', 'Yes'),
(27, 'Sandwich', 'Food_Category_74.jpg', 'Yes', 'Yes'),
(28, 'Beverages', 'Food_Category_208.jpg', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(31, 'Smoky BBQ Pizza', 'Best firewood pizza in town', '6.00', 'Food_Name_8341.jpg', 22, 'Yes', 'Yes'),
(34, 'Dumplings Specials', 'Chicken Dumplings with herbs from mountain', '5.00', 'Food_Name_9052.jpg', 25, 'Yes', 'Yes'),
(35, 'Best Burger', 'Best burger with ham, lots of cream and tasty graby.', '4.00', 'Food_Name_8511.jpg', 24, 'Yes', 'Yes'),
(40, 'Mixed Pizza', 'Pizza with chicken, Ham, Buff, Mushroom, and Vegetables', '10.00', 'Food_Name_4101.jpg', 22, 'Yes', 'Yes'),
(41, 'Sadeko Momo', 'Best Spicy Momo for Winters', '6.00', 'Food_Name_5457.jpg', 25, 'Yes', 'Yes'),
(42, 'Non veg Burger', 'Non veg Burger with extra  cheese,20% extra chicken and cream .', '6.00', 'Food-Name-1861.jpg', 24, 'No', 'Yes'),
(43, 'asy Creamy Four Cheese Pasta', 'This is one of those dishes that is great on its own or as a side next to some grilled chicken, a juicy steak, or with some roasted mushrooms.', '5.00', 'Food-Name-5134.jpg', 26, 'Yes', 'Yes'),
(44, 'BOMBAY GRILLED CHUTNEY SANDWICH', 'vibrant herb chutney sandwich, layered with crunchy fresh veggies and grilled to perfection and you’ll see why it’s such an iconic snack in India and one of Mumbai’s favorite street foods.', '6.00', 'Food_Name_6850.jpg', 27, 'Yes', 'Yes'),
(45, 'Mountain Dew', '2 litre  moiunatin dew make your mind fresh.', '1.00', 'Food_Name_611.jpg', 28, 'Yes', 'Yes'),
(46, 'Coca-Cola No Sugar Can  (300 ml)', 'Cold and chilled coca cola.', '2.00', 'Food-Name-1147.jpg', 28, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(8, 'Sadeko Momo', '6.00', 3, '18.00', '2021-06-18 06:58:49', 'Cancelled', 'Kellie Schwartz', '+1 (511) 542-7635', 'lyna@mailinator.commmmmmmmmmmmm', 'Veritatis laboris qu'),
(9, 'Sadeko Momo', '6.00', 2, '12.00', '2021-06-18 12:06:56', 'Delivered', 'Sheila Walton', '+1 (201) 713-8254', 'rycotyhe@mailinator.com', 'Velit doloremque pr'),
(10, 'Best Burger', '4.00', 1, '4.00', '2021-06-18 12:07:55', 'Ordered', 'Kadeem Weeks', '+1 (776) 676-8367', 'faxo@mailinator.com', 'Sed quo et assumenda'),
(11, 'Smoky BBQ Pizza', '6.00', 521, '3126.00', '2021-06-20 09:30:24', 'Delivered', 'Macy Buchanan', '+1 (222) 845-3214', 'fopetomo@mailinator.com', 'Aut ea ipsa volupta'),
(12, 'Smoky BBQ Pizza', '6.00', 3, '18.00', '2021-06-20 09:33:07', 'On Delivery', 'adarsh Mishra', '9846785234', 'mishraadarsh602@gmail.com', 'H-670, G-block, phase, aya nagar, new delhi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
