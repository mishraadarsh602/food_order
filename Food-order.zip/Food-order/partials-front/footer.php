<style>
    body {
        margin: 0;
        overflow-x: hidden;
    }

    footer {
        width: 100%;
        background-color:#2f3542;
        padding:30px;
        padding-bottom:0px;
        font-family: 'Open Sans', sans-serif;
    }

    footer .column {
        width: 17%;
        display: inline-block;
        vertical-align: top;
        padding: 10px;
    }

    footer .column .footer_title {
        color: #fff;
        font-size: 1em;
        font-weight: 700;
        cursor: default;
    }

    footer .column a {
        text-decoration: none;
        display: block;
        color: gray;
        font-size: 0.9em;
        padding: 5px 0;
        font-weight: 400;
        transition: 0.5s;
    }

    footer .column:not(:first-child) a:hover {
        color: #fff;
    }

    footer .column:nth-child(4) a:not(:first-child) {
        margin: 5px;
        display: inline-block
    }

    footer .column:nth-child(1) a:nth-child(3),
    footer .column:nth-child(1) a:nth-child(4),
    footer .column:nth-child(1) a:nth-child(5) {
        display: inline-block;
        margin: 10px;
        font-size: 1.3em;
        background: #fff;
        width: 28px;
        height: 28px;
        text-align: Center;
        border-radius: 50%;
        padding: 5px;
    }

    footer .column:nth-child(1) .fa-facebook {
        color: #3B5998;
    }

    footer .column:nth-child(1) .fa-instagram {
        color: #d62977;
    }

    footer .column:nth-child(1) .fa-twitter {
        color: #3399ff;
    }

    .sub-footer {
        background: #2f3542;
        width: 100%;
        padding: 5px 0;
        text-align: center;
        color: gray;
        font-size: 12px;
        padding:20px;
    }

    @media (max-width:1100px) {

        footer .column:nth-child(1) a:nth-child(3),
        footer .column:nth-child(1) a:nth-child(4),
        footer .column:nth-child(1) a:nth-child(5) {
            width: 23px;
            height: 23px;
            font-size: 1.1em;
            margin: 6px;
        }
    }


    @media (max-width:820px) {
        footer .column:nth-child(1) {
            width: 95%;
            display: block;
        }

        footer .column:not(:first-child) {
            width: 40%;
        }

        footer .column:nth-child(4),
        footer .column:nth-child(5) {
            width: 95%;
            display: block;
        }

        footer .column:nth-child(1) a:nth-child(3),
        footer .column:nth-child(1) a:nth-child(4),
        footer .column:nth-child(1) a:nth-child(5) {
            width: 28px;
            height: 28px;
            font-size: 1.3em;
        }
    }
</style>
<!-- social Section Starts Here -->
<!--  <section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    -->
<!-- social Section Ends Here -->
<!-- footer Section Starts Here -->
<!--
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a href="#">Adarsh Mishra</a></p>
        </div>
    </section>
    -->
<!-- footer Section Ends Here -->


<!--codepen footer-->
<footer>

    <div class="column">
        <a class="footer_title">FAST FOOD CORNER</a>
        <a>Fast food Corner is the fast food website. It provides different categories of foods with different items. Free delivery is available at any amount purchased by customers. </a>
        <a href="#" title="Facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" title="Instagram"><i class="fa fa-instagram"></i></a>
        <a href="#" title="Twitter"><i class="fa fa-twitter"></i></a>
    </div>
    <div class="column">
        <a class="footer_title">OTHER LINKS</a>
        <a href="#">Privacy Policy</a>
        <a href="#">Terms & Conditions</a>
        <a href="<?php echo SITEURL;?>foods.php">Order now</a>
    </div>
    <div class="column">
        <a class="footer_title">SHORT CUT</a>
        <a href="<?php echo SITEURL;?>categories.php">Categories</a>
        <a href="">Our Blog</a>
        <a href="<?php echo SITEURL;?>contacts.php">Contact Us</a>
        <a href="">About Us</a>
    </div>
    <div class="column">
        <a class="footer_title">LATEST FOOD</a>
        <a href="<?php echo SITEURL;?>categories.php" title="Pizza"><img src="https://source.unsplash.com/50x50/?pizza"></a>
        <a href="<?php echo SITEURL;?>categories.php" title="Pepsi"><img src="https://source.unsplash.com/50x50/?limca,pepsi"></a>
        <a href="<?php echo SITEURL;?>categories.php" title="Burger"><img src="https://source.unsplash.com/50x50/?burger"></a>
        <a href="<?php echo SITEURL;?>categories.php" title="Pasta"><img src="https://source.unsplash.com/50x50/?pasta"></a>
        <a href="<?php echo SITEURL;?>categories.php" title="Momos"><img
                src="https://source.unsplash.com/50x50/?Dumplings"></a>
    </div>
    <div class="column">
        <a class="footer_title">GET IN TOUCH</a>
        <a title="Address"><i class="fa fa-map-marker"></i> 007, street, Ghitorni/Delhi, India - 110047</a>
        <a href="emailto:" title="Email"><i class="fa fa-envelope"></i> fastfoodcorner@gmail.com</a>
        <a href="tel:" title="Contact"><i class="fa fa-phone"></i> +(91)-94537-11111</a>
    </div>

    <hr style="color:grey;width:90%;margin:0 auto;">
</footer>

<div class="sub-footer">
        © CopyRights 2021 Fast Food Corner || All rights reserved
    </div>

</body>

</html>