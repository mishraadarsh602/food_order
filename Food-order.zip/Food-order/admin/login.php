<?php
//connect to database
include('../config/constants.php');
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin - Login</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <!--link to style admin--->
<style>
    /*----------login admin-----*/
.login-admin{
margin-top:2em;
}
.login-sect{
  width:300px;
height:500px;
margin:1em auto;
background-color:white;
box-shadow:0px 0px 30px  black;
}

</style>   
  </head>
  <body style="background-color:lightblue;">
       <div class="container login-sect">
           <h2>Login Admin</h2>
          <br>
      <?php
      if(isset($_SESSION['login'])){
        echo $_SESSION['login'];
        
       unset($_SESSION['login']);
      }
      if(isset($_SESSION['no-login-message'])){
       echo $_SESSION['no-login-message'];
        unset( $_SESSION['no-login-message']);
      }
      
      ?> 
           <br><br>
          <form action="" method="POST" class="login-admin">
                 <div class="form-group">
                  <label for="exampleInputEmail2">Username</label>
                   <input type="text" class="form-control" name="username" id="exampleInputEmail2" aria-describedby="emailHelp">
                 </div>
                <div class="form-group">
                 <label for="exampleInputPassword2">Password</label>
                 <input type="password" class="form-control" name="password" id="exampleInputPassword2">
                </div>
               <button type="submit" name="submit" class="btn btn-primary">Submit</button>
           </form>

           <?php

              if(isset($_POST['submit'])){
               // $username=$_POST['username'];
                // $password=md5($_POST['password']);
                 $username=mysqli_real_escape_string($conn,$_POST['username']);
                 $password=mysqli_real_escape_string($conn,md5($_POST['password']));

                  //sql to check whther username and password is exist or not
                 $sql="SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";

                   //execute the query
                   $res=mysqli_query($conn,$sql);
                  
                  
                    // echo "query run ";
                     $count=mysqli_num_rows($res);
                     if($count==1){
                      $_SESSION['login']='<div class="text-success">You login successfully</div>';

                      //check whether user login or not
                      $_SESSION['user']=$username;
                      $_SESSION['welcome']="<div class='text-warning'>Welcome $username</div>";
                      

                      //redirect page
                      header('location:'.SITEURL.'admin/');
                     }
                     else{
                      $_SESSION['login']='<div class="text-danger">You failed to login</div>';
                      //redirect page
                      header('location:'.SITEURL.'admin/login.php');
                     }
                 
 
}

?>
     </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>

