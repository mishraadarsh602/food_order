<?php
include ('partials/menu.php');
?>


 <!-------main-content section starts-->
 <div class="main-content">
           <div class="wrapper add-admin-sec">
               <h1>Add Admin</h1>
               <br>
               <?php 
     if(isset($_SESSION['add'])){
        echo $_SESSION['add'];    //display session message
        unset ($_SESSION['add']);  //remove session message
     }
    ?>
               <form action="" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Full Name</label>
    <input type="text" class="form-control" name="full_name" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Username</label>
    <input type="text" class="form-control"  name="username" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="password" id="exampleInputPassword1">
  </div>
 
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>

              
           </div>
       </div>
       <!-------main-content section ends-->
      
<?php  include ('partials/footer.php'); ?>

<?php
//process data and save it to database
//check whether submit button is clicked or not
if(isset($_POST['submit'])){
      //button clicked get data from user form
    $fullname=$_POST['full_name'];
    $username=$_POST['username'];
    $password=md5($_POST['password']);

    //sql query to save data into database
    $sql="INSERT INTO tbl_admin SET
     full_name='$fullname',
     username='$username',
     password='$password'
    ";
    //executing the upword query
    $res=mysqli_query($conn,$sql) or die(mysqli_error());
   
    //check whether data is inserted or not
    if($res==TRUE){
      //create session var to display message
      $_SESSION['add']='<div class="text-success">Admin added to category</div>';
      //redirect page
      header('location:'.SITEURL.'admin/manage-admin.php');
    }
    else{
      $_SESSION['add']='<div class="text-danger">Failed to add admin</div>';
      //redirect page
      header('location:'.SITEURL.'admin/add-admin.php') ;  
     }

}

?>