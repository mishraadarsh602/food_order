<?php
include ('partials/menu.php');
?>


 <!-------main-content section starts-->
 <div class="main-content">
   <div class="wrapper">
               <h1>Add Category</h1>
               <br><br>
               <?php
               
               if(isset($_SESSION['add'])){
                   echo $_SESSION['add'];
                   unset($_SESSION['add']);
               }
               
               if(isset($_SESSION['upload'])){
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }
            
               ?>
               <br>
               <br>
          <form action="" method="POST" enctype="multipart/form-data">
              <table class="table">
                  <tr>
                      <td>Title : <input type="text" placeholder="Category title" name="title"></td>
                     
                    
                  </tr>
                  <tr>
                  <td>Select Image :  </td>
                  <td><input type="file" name="image"></td>
                  </tr>
                  <tr>
                  <td>Featured : 
                    <input type="radio" name="featured" value="Yes">Yes 
                    <input type="radio" name="featured" value="No">No </td>

                  </tr>
                  <tr>
                  <td>Active : 
                      <input type="radio" name="active" value="Yes">Yes 
                      <input type="radio" name="active" value="No">No </td>
                  </tr>
                  <tr>
                      <td colspan="2"><input type="submit" name="submit" value="Add Category" class="btn-primary"></td>
                  </tr>
              </table>
         </form>
         </div>
       </div>
       <!-------main-content section ends-->
       <?php 
       
       //check whether button is clicked or not
       if(isset($_POST['submit'])){
          // echo "clicked";
          //get value from category form
          $title=$_POST['title'];
             //for radio input, we have to check whether user click radio button or not
             //check featured radio
             if(isset($_POST['featured'])){
                  $featured=$_POST['featured'];

             }
             else{
                  // give default value  No
                  $featured="No";

             }
             //check radio active
             if(isset($_POST['active'])){
                $active=$_POST['active'];

           }
           else{
                // give default value  No
                $active="No";

           }

           //check whether the image is selected or not and give the name of image accordingly
           //$_FILES[] is an array and echo dont show array as ouput so we use print_r
          // print_r($_FILES['image']);
         //  die();
         if(isset($_FILES['image']['name']))
         {
             //upload image
             //to upload image we need source path , destination path and image name
           $image_name=$_FILES['image']['name'];
           //upload img if img is selected
           if($image_name!="")
           {
            //auto rename our image
           //get extension of an image (jpg,jpeg,png,gif etc..) eg. "food.jpg"
           $ext=end(explode('.',$image_name));   //get last ext value using end(explode('.'))
           //rename the image
           $image_name="Food_Category_".rand(000,999).'.'.$ext; //Food_Category_527.jpg
           $source_path=$_FILES['image']['tmp_name'];
           $destination_path="../images/category/".$image_name;

           //upload file
           $upload=move_uploaded_file($source_path,$destination_path);
           
           //check whether image is uploaded or not
           //if image isnot uploaded then send error message
               if($upload==FALSE)
               {
                  $_SESSION['upload']="<div class='text-danger'>Failed to upload image</div>";
                  //redirect to add category page
                  header('location:'.SITEURL.'admin/add-category.php');
                  die(); //use die to stop uploading blank image

               }
           }
          
         }
         else{
           //dont upload image and set image name as blank
           $image_name="";
         }

           //create sql query to insert catory into tbl_category table  
           $sql="INSERT INTO tbl_category SET
           title='$title',
           image_name='$image_name',
           featured='$featured',
           active='$active'";

           //run the query
           $res=mysqli_query($conn,$sql);

           //check query executed or category added or not
           if($res==TRUE){
            $_SESSION['add']='<div class="text-success">Category added successfully</div>';
            header('location:'.SITEURL.'admin/manage-category.php');
           }
           else{
            $_SESSION['add']='<div class="text-danger"> Failed to add category</div>';
            header('location:'.SITEURL.'admin/add-category.php');
           }


       }
       
       ?>
      
<?php

include ('partials/footer.php');
?>