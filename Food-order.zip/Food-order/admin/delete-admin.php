<?php
include('../config/constants.php');

//get id of admin to be deleted
$id=$_GET['id'];

//create sql query to delete admin 
$sql="DELETE FROM tbl_admin WHERE id=$id";

//execute query
$res=mysqli_query($conn,$sql);

//check query execeuted or not
if($res==TRUE){
    //echo  "Admin deleted";
    //create session var to display message
    $_SESSION['delete']='<div class="text-success">Admin deleted successfully</div>';
    header('location:'.SITEURL.'admin/manage-admin.php');
}
else{
   // echo  " failed to delete admin";
   $_SESSION['delete']='<div class="text-danger">Admin Failed to delete</div>';
    header('location:'.SITEURL.'admin/manage-admin.php');

}
//redirect page to manage admin page with message (success/error)



?>