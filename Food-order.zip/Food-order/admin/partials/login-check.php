<?php

//authorizatin and access control
 
if(!isset($_SESSION['user'])){  // if user not logged in then show message and dont allow him to see any admin pages
   
    $_SESSION['no-login-message']='<div class="text-danger">Please login to access admin panel</div>';
    //redirect page to login page
    header('location:'.SITEURL.'admin/login.php') ;

}
?>