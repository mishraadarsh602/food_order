<?php
include ('partials/menu.php');
?>

<!-------main-content section starts-->
<div class="main-content">
  <div class="wrapper">
    <h1>Update Password</h1>
    <br><br>
     <?php  
     
     if(isset($_GET['id'])){
         $id=$_GET['id'];
     }
     ?>
    <!---form to update admin--->
    <form action="" method="post">
      <div class="form-group">
        <label for="exampleInputEmail1">Current Password</label>
        <input type="password" class="form-control" name="current_password" value=""
          id="exampleInputEmail1" aria-describedby="emailHelp">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">New Password</label>
        <input type="password" class="form-control" name="new_password" value="" id="exampleInputEmail1"
          aria-describedby="emailHelp">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Confirm Password</label>
        <input type="password" class="form-control" name="confirm_password" value="" id="exampleInputEmail1"
          aria-describedby="emailHelp">
      </div>
      <input type="hidden" name="id" value="<?php echo $id; ?>">
      <button type="submit" name="submit" class="btn btn-primary">Submit</button>
    </form>
    
   

  </div>
</div>
<!-------main-content section ends-->

<?php  

if(isset($_POST['submit'])){
    //echo "clicked";

    //get data from form
    $id=$_POST['id'];
    $current_password=md5($_POST['current_password']);
    $new_password=md5($_POST['new_password']);
    $confirm_password=md5($_POST['confirm_password']);

    //check whether id and current password exists in database or not
    $sql="SELECT * FROM tbl_admin WHERE id=$id AND password='$current_password'";
    //execute query
    $res=mysqli_query($conn,$sql);
    if($res==TRUE){
      $count=mysqli_num_rows($res);
      if($count==1){
          //user exists and password can change
         // echo "user found";
         if($new_password==$confirm_password){
             //update password
            // echo "password match";
            $sql2="UPDATE tbl_admin SET
            password='$new_password' WHERE id=$id";
            //execute query
            $res2=mysqli_query($conn,$sql2);
            //CHECK whether query is executed or not
            if($res2==TRUE){
                 //display messge
                 $_SESSION['change-pwd']='<div class="text-success">Password change successfully</div>';
                 header('location:'.SITEURL.'admin/manage-admin.php');
            }
            else{
                //display error message
                $_SESSION['change-pwd']='<div class="text-danger">Failed to chnage password</div>';
                header('location:'.SITEURL.'admin/manage-admin.php');
            }
         }
         else{
              //new and current password not match
          //redirect to manage-admin
          $_SESSION['pwd-not-match']='<div class="text-danger">Password not match!</div>';
          header('location:'.SITEURL.'admin/manage-admin.php');
         }
      }
    else{
          //user doesnot exist and you can't change the password 
          //redirect to manageadmin
          $_SESSION['user-not-found']='<div class="text-danger">User not Found!!!!</div>';
          header('location:'.SITEURL.'admin/manage-admin.php');

      }

    }
}

?>
<?php

include ('partials/footer.php');
?>