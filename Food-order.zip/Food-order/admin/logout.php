<?php

include('../config/constants.php');

//destroy the session
session_destroy();  //unset the $_SESSION['user']

//redirect to login page
header('location:'.SITEURL.'admin/login.php');

?>