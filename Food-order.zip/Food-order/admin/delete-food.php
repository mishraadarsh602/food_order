<?php
 include('../config/constants.php');

 
 if(isset($_GET['id']) && isset($_GET['image_name']))
 {
  // delete it
    //echo "process to delete";
    //get id & imgename 
    $id=$_GET['id'];
    $image_name=$_GET['image_name'];
    //remove image if available
    //check whther the imge is availble or not and delete image if available
    if($image_name!="")
    {
     //it has image and need to delete it from folder
     //get image path
     $path="../images/food/".$image_name;
     $remove=unlink($path);
     //chk whther the inage is remove or not
     if($remove==false)
     {
     //failed to remove image
     $_SESSION['upload']="<div class='text-danger'>Failed to remove image</div>";
     //redirect to manage-food page
     header('location:'.SITEURL.'admin/manage-food.php');
     die(); //to stop process
     }
    }

    //delete food from database
    $sql="DELETE FROM tbl_food WHERE id=$id";
    //execute query
    $res=mysqli_query($conn,$sql);
    //chk query result executed or not and set the session message respectively
     if($res==true)
     {
        $_SESSION['delete']='<div class="text-success">Food deleted successfully</div>';
        header('location:'.SITEURL.'admin/manage-food.php');
     }
     else
     {
        $_SESSION['delete']='<div class="text-danger">failed to  delete food</div>';
        header('location:'.SITEURL.'admin/manage-food.php');
     }
 }
 else{
    //echo "redirect to manage-food";
    $_SESSION['unauthorize']="<div class='text-danger'>Unauthorized access</div>";
    //redirect to add category page
    header('location:'.SITEURL.'admin/manage-food.php');
 }
?>