<?php 

   include('../config/constants.php');
   //echo "hii" ;
  //  check whether id or img name is set or not
  if(isset($_GET['id']) AND isset($_GET['image_name'])){
      //get value and delete
     $id=$_GET['id'];
     $image_name=$_GET['image_name'];
     //remove physical imge file if available
      if($image_name!=""){
          //img is available . so remove it
          $path="../images/category/".$image_name;
          //remove it
          $remove=unlink($path);
          if($remove==false){
              //set session message
              $_SESSION['remove']='<div class="text-danger">failed to delete category img</div>';
              header('location:'.SITEURL.'admin/manage-category.php');
              die();  // to stop process
              //

          }
      }
     

     //delete data from database
     $sql="DELETE FROM tbl_category WHERE id=$id";
     //execute query
     $res=mysqli_query($conn,$sql);
     //check whether data is deleted or not
     if($res==true){
         //set success and redirect
         $_SESSION['delete']='<div class="text-success">deleted successfully</div>';
         header('location:'.SITEURL.'admin/manage-category.php');
  
     }else{
         //failed message
         $_SESSION['delete']='<div class="text-danger">failed to delete category</div>';
              header('location:'.SITEURL.'admin/manage-category.php');

     }

     //redirect to manage-category page with message
  }else{
      header('location:'.SITEURL.'admin/manage-category.php');
  }

?>