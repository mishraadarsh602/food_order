<?php
include ('partials/menu.php');
?>

            <!-------main-content section starts-->
        <div class="main-content">
          <div class="wrapper">
            <h1>Update Category</h1>
            <br><br>

            <br>
            <br>
            <?php
            //check  is set or not
            if(isset($_GET['id']))
            {
            //get id and all other details
            //echo "getting data";
            $id=$_GET['id'];

            //create sql query  to get all data
            $sql="SELECT * FROM tbl_category WHERE id=$id";
            //execute query
            $res=mysqli_query($conn,$sql);

            $count=mysqli_num_rows($res);

            if($count==1){

                $row=mysqli_fetch_assoc($res);
                $title=$row['title'];
                $current_image=$row['image_name'];
                $featured=$row['featured'];
                $active=$row['active'];
                
            }
            else
            {
                //if category not found redirect to manage category page
                $_SESSION['no-category-found']='<div class="text-danger">Category not found!</div>';
                header('location:'.SITEURL.'admin/manage-category.php');
            }

            }
            else
            {
                header('location:'.SITEURL.'admin/manage-category.php');
            }


            ?>

            <form action="" method="POST" enctype="multipart/form-data">
                <table class="table">
                    <tr>
                        <td>Title : <input type="text" placeholder="" value="<?php echo $title; ?>" name="title"></td>
                    </tr>
                    <tr>
                        <td>Current Image : </td>
                        <td>
                            <?php
                        if($current_image!="")
                        {
                            ?>
                            <img src="<?php echo SITEURL;?>/images/category/<?php echo $current_image;?>" alt=""
                                width="150px">
                            <?php

                        }
                        else 
                        {
                            echo "<div class='text-danger'>Image not added</div>";
                        }
                        
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>New Image : </td>
                        <td><input type="file" name="image"></td>
                    </tr>
                    <tr>
                        <td>Featured :
                            <input <?php if($featured=="Yes" ){echo "checked" ;}?> type="radio" name="featured"
                            value="Yes">Yes
                            <input <?php if($featured=="No" ){echo "checked" ;}?> type="radio" name="featured" value="No">No
                        </td>

                    </tr>
                    <tr>
                        <td>Active :
                            <input <?php if($active=="Yes" ){echo "checked" ;}?> type="radio" name="active" value="Yes">Yes
                            <input <?php if($active=="No" ){echo "checked" ;}?> type="radio" name="active" value="No">No
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="hidden" name="current_image" value="<?php echo $current_image;?>">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="submit" name="submit" value="update Category" class="btn-primary">
                        </td>
                    </tr>
                </table>
            </form>

        <?php
         
         if(isset($_POST['submit'])){
       
             //echo "clicked";
             //get all value from the form
             $id=$_POST['id'];
             $title=$_POST['title'];
             $current_image=$_POST['current_image'];
             $featured=$_POST['featured'];
             $active=$_POST['active'];

             //updating img
             //check whether the imge is selected or not
             if(isset($_FILES['image']['name']))
             {
                 $image_name=$_FILES['image']['name'];
                 //check whether the img is available or not
                 if($image_name!="")
                 {
                  //img available
                  //A. upload new img
                   //auto rename our image
           //get extension of an image (jpg,jpeg,png,gif etc..) eg. "food.jpg"
           $ext=end(explode('.',$image_name));   //get last ext value using end(explode('.'))
           //rename the image
           $image_name="Food_Category_".rand(000,999).'.'.$ext; //Food_Category_527.jpg
           $source_path=$_FILES['image']['tmp_name'];
           $destination_path="../images/category/".$image_name;

           //upload file
           $upload=move_uploaded_file($source_path,$destination_path);
           
           //check whether image is uploaded or not
           //if image isnot uploaded then send error message
               if($upload==FALSE)
               {
                  $_SESSION['upload']="<div class='text-danger'>Failed to upload image</div>";
                  //redirect to add category page
                  header('location:'.SITEURL.'admin/manage-category.php');
                  die(); //use die to stop uploading blank image

               }


               if($current_image!=""){
                  //B. remove current img
                  $remove_path="../images/category/".$current_image;
                  $remove=unlink($remove_path);
                 
                  //check whether img is remove or not 
                  //if failed to remove display failed to remove 
                     if($remove==false)
                     {
                      $_SESSION['failed-remove']="<div class='text-danger'>Failed to remove current image</div>";
                    //redirect to add category page
                    header('location:'.SITEURL.'admin/manage-category.php');
                    die(); //use die to stop uploading blank image
                     }
               }
                
                 }
                 else
                 {
                    $image_name=$current_image;
                 }

             }
             else{
                 $image_name=$current_image;
             }

             //update database
             $sql2="UPDATE tbl_category SET
             image_name='$image_name',
             title='$title',
             featured='$featured',
             active='$active'
             WHERE id=$id
             ";
             //execute query
             $res2=mysqli_query($conn,$sql2);
             //redirect to manage category with message
             //check query is executed or not
             if($res2==true)
             {
                 //
                 $_SESSION['update']="<div class='text-success'>Category updated successfully</div>";
                 //redirect to add category page
                 header('location:'.SITEURL.'admin/manage-category.php');
             }
             else{
                $_SESSION['update']="<div class='text-danger'>Failed to update category</div>";
                //redirect to add category page
                header('location:'.SITEURL.'admin/manage-category.php');

             }



         }
         ?>


    </div>
</div>
<!-------main-content section ends-->

<?php
include ('partials/footer.php');
?>